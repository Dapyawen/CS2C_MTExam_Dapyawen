let fullName = "Aldrin Dapyawen";
let age = 20;
let favoriteNumber = 8;
let favoriteColor = "Green";
console.log("Full Name:", fullName);
console.log("Age:", age);
console.log("Favorite Number:", favoriteNumber);
console.log("Favorite Color:", favoriteColor);