let subjectTitle = "Data Structures and Algorithms";
let classSchedule = "Tuesday and Thursday, 8:00 AM 9:30 AM";
let classroom = "ComLab B";
let classInstructor = "Sir Cliff Owen Pascua";
let studentName = "Aldrin Dapyawen";

console.log('${studentName} is currently enrolled in ${subjectTitle} with a class schedule of ${classSchedule} at room ${classroom). The instructor for the subject is ${classInstructor}.`);