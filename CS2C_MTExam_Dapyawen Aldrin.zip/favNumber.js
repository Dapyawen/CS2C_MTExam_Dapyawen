let favNumber = 8;
let guess;
let attempts = 0;
while (guess!== favNumber) {
guess = parseInt(prompt("Guess my favorite number:"));
attempts++;
if (guess favNumber) 
console.log("Too low! Try again." );
} else if (guess > fav Number) {
console.log("Too high! Try again .");
} else {
  console.log('Correct nice one! It took you ${attempts} attempts.` );