let colors = [];// Function to get user input for colors
function getColors() {
for (let i=0; i < 3; i++) {

let color=prompt(`Enter color ${i + 1}:`);
colors.push(color); // Add the color to the array
console.log(colors); // Print the updated array
function addColor() {
let newColor = prompt("Enter a new color to add: ");
colors.push(newColor); // Add the new color
console.log(colors); // Print the updated array

getColors();
addColor();