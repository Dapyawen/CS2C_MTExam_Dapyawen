let userProfile = {

fullName: "Aldrin Dapyawen",
age: 20,
favoriteNumber: 8,
favoriteColors: ["green", "black"]
};
console.log(userProfile);