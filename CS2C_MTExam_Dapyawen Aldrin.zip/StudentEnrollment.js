// Initialize subject arrays
let DSA = [];
let PL = [];
let Networks = [];

// Function to display the menu
function showMenu() {
    console.log("\nOperations:");
    console.log("A) Enroll");
    console.log("B) Unenroll");
    console.log("C) Select Another Subject");
    console.log("D) Exit");
    let operation = prompt("Select an option (A/B/C/D): ").toUpperCase();

    switch (operation) {
        case 'A':
            enrollStudent();
            break;
        case 'B':
            unenrollStudent();
            break;
        case 'C':
            selectSubject();
            break;
        case 'D':
            exitProgram();
            break;
        default:
            console.log("Invalid option. Please try again.");
            showMenu();
    }
}

// Function to select a subject
function selectSubject() {
    console.log("\nSubjects:");
    console.log("A) DSA");
    console.log("B) PL");
    console.log("C) Networks");
    let subjectChoice = prompt("Select a subject to enroll/unroll (A/B/C): ").toUpperCase();

    switch (subjectChoice) {
        case 'A':
            handleSubject(DSA, "DSA");
            break;
        case 'B':
            handleSubject(PL, "PL");
            break;
        case 'C':
            handleSubject(Networks, "Networks");
            break;
        default:
            console.log("Invalid subject. Please try again.");
            selectSubject();
    }
}

// Function to handle enroll/unroll for a given subject
function handleSubject(subjectArray, subjectName) {
    console.log(`\nYou have selected ${subjectName}.`);
    showMenu();
}

// Function to enroll a student
function enrollStudent() {
    let studentName = prompt("Enter the name of the student to enroll: ");
    let subjectChoice = prompt("\nSelect a subject to enroll the student (A) DSA, (B) PL, (C) Networks: ").toUpperCase();

    switch (subjectChoice) {
        case 'A':
            DSA.push(studentName);
            console.log(`${studentName} has been enrolled in DSA.`);
            break;
        case 'B':
            PL.push(studentName);
            console.log(`${studentName} has been enrolled in PL.`);
            break;
        case 'C':
            Networks.push(studentName);
            console.log(`${studentName} has been enrolled in Networks.`);
            break;
        default:
            console.log("Invalid subject. Please try again.");
            enrollStudent();
    }

    showMenu();
}

// Function to unenroll a student
function unenrollStudent() {
    let subjectChoice = prompt("\nSelect a subject to unenroll a student (A) DSA, (B) PL, (C) Networks: ").toUpperCase();

    switch (subjectChoice) {
        case 'A':
            if (DSA.length > 0) {
                console.log("Current DSA students:", DSA);
                let studentName = prompt("Enter the name of the student to unenroll: ");
                let index = DSA.indexOf(studentName);
                if (index !== -1) {
                    DSA.splice(index, 1);
                    console.log(`${studentName} has been unenrolled from DSA.`);
                } else {
                    console.log(`${studentName} is not enrolled in DSA.`);
                }
            } else {
                console.log("No students are currently enrolled in DSA.");
            }
            break;
        case 'B':
            if (PL.length > 0) {
                console.log("Current PL students:", PL);
                let studentName = prompt("Enter the name of the student to unenroll: ");
                let index = PL.indexOf(studentName);
                if (index !== -1) {
                    PL.splice(index, 1);
                    console.log(`${studentName} has been unenrolled from PL.`);
                } else {
                    console.log(`${studentName} is not enrolled in PL.`);
                }
            } else {
                console.log("No students are currently enrolled in PL.");
            }
            break;
        case 'C':
            if (Networks.length > 0) {
                console.log("Current Networks students:", Networks);
                let studentName = prompt("Enter the name of the student to unenroll: ");
                let index = Networks.indexOf(studentName);
                if (index !== -1) {
                    Networks.splice(index, 1);
                    console.log(`${studentName} has been unenrolled from Networks.`);
                } else {
                    console.log(`${studentName} is not enrolled in Networks.`);
                }
            } else {
                console.log("No students are currently enrolled in Networks.");
            }
            break;
        default:
            console.log("Invalid subject. Please try again.");
            unenrollStudent();
    }

    showMenu();
}

// Function to exit the program
function exitProgram() {
    console.log("\nFinal Enrollment Status:");
    console.log("DSA:", DSA);
    console.log("PL:", PL);
    console.log("Networks:", Networks);
    console.log("Exiting the program...");
}

// Start the program by selecting a subject
selectSubject();
